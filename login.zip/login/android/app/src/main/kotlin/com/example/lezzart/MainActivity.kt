package com.lezzart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
